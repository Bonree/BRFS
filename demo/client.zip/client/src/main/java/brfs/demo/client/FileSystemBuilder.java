package brfs.demo.client;

import com.bonree.brfs.client.BRFileSystem;
import com.bonree.brfs.client.impl.DefaultBRFileSystem;
import com.bonree.brfs.client.impl.FileSystemConfig;

public class FileSystemBuilder {
	
	public static BRFileSystem getFileSystem() throws Exception {
		return new DefaultBRFileSystem(FileSystemConfig.newBuilder()
				.setClusterName("cluster_name")
				.setUsername("user")
				.setPasswd("pd")
				.setConnectionPoolSize(10)
				.setZkAddresses("1.0.0.1:2181,1.0.0.2:2181")
				.build());
	}
}
