package brfs.demo.client;

import java.util.HashMap;
import java.util.Map;

import com.bonree.brfs.client.BRFileSystem;

public class StorageRegionCreateDemo {
	
	public static void main(String[] args) throws Exception {
		BRFileSystem fs = FileSystemBuilder.getFileSystem();
		
		Map<String, Object> attrs = new HashMap<String, Object>();
		//设置数据的副本数
		attrs.put("replicate_num", 2);
		//还有一些额外的设置值，可以不用设置，系统会使用默认值填充
		
		boolean result = fs.createStorageName("sr_demo", attrs);
		System.out.println("create result : " + result);
	}
}
