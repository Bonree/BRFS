package brfs.demo.client;

import com.bonree.brfs.client.BRFileSystem;
import com.bonree.brfs.client.InputItem;
import com.bonree.brfs.client.StorageNameStick;

public class WriteDemo {
	
	private static final byte[] DATA_DEMO = "123456".getBytes();

	public static void main(String[] args) throws Exception {
		BRFileSystem fs = FileSystemBuilder.getFileSystem();
		
		StorageNameStick stick = fs.openStorageName("sr_demo");
		if(stick != null) {
			//########每次写入一条数据############
			String fileId = stick.writeData(new SimpleInputItem(DATA_DEMO));
			//store file id
			
			//########每次批量写入数据############
			String[] fidList = stick.writeData(new InputItem[] {
					new SimpleInputItem(DATA_DEMO),
					new SimpleInputItem(DATA_DEMO),
					new SimpleInputItem(DATA_DEMO)
			});
			//store file ids
		}
	}
	
	public static class SimpleInputItem implements InputItem {
		private final byte[] data;
		
		public SimpleInputItem(byte[] data) {
			this.data = data;
		}

		@Override
		public byte[] getBytes() {
			return data;
		}
		
	}
}
