package brfs.demo.client;

import com.bonree.brfs.client.BRFileSystem;
import com.bonree.brfs.client.InputItem;
import com.bonree.brfs.client.StorageNameStick;

public class ReadDemo {
	private static final String FID_DEMO = "";

	public static void main(String[] args) throws Exception {
		BRFileSystem fs = FileSystemBuilder.getFileSystem();
		
		StorageNameStick stick = fs.openStorageName("sr_demo");
		if(stick != null) {
			try {
				InputItem item = stick.readData(FID_DEMO);
				if(item != null) {
					byte[] fileContent = item.getBytes();
					
					//handle file content
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
